package com.example.tour;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = (TabLayout) findViewById(R.id.tb);
        viewPager = (ViewPager) findViewById(R.id.vp);
         adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.Addfragment(new fragmentchandi(),"Chandigarh");
         adapter.Addfragment(new fragmentbihar(),"Bihar");
        adapter.Addfragment(new fragmentkol(),"West Bengal");


         viewPager.setAdapter(adapter);
         tabLayout.setupWithViewPager(viewPager);
    }


}
