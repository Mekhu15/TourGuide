package com.example.tour;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class fragmentbihar extends Fragment implements View.OnClickListener {

    View v;
    public fragmentbihar() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.bihar,container,false);
        Button bh1 = (Button) v.findViewById(R.id.bh1);
        bh1.setOnClickListener(this);
        Button bh2 = (Button) v.findViewById(R.id.bh2);
        bh2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(getActivity(),b_res.class);
                startActivity(j);
            }
        });
        Button bh3 = (Button) v.findViewById(R.id.bh3);
        bh3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),b_hot.class);
                startActivity(i);
            }
        });
        return v;
    }


    @Override
    public void onClick(View v) {
        Intent i = new Intent(getActivity(),bihar.class);
        startActivity(i);


    }
}
