package com.example.tour;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class fragmentchandi extends Fragment implements View.OnClickListener{

    View v;
    public fragmentchandi() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.chandi,container,false);

        Button b1 = (Button) v.findViewById(R.id.bch1);
        b1.setOnClickListener(this);

        Button b2 = (Button) v.findViewById(R.id.bch2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent k = new Intent(getActivity(),c_restro.class);
                startActivity(k);
            }
        });


        Button b3 = (Button) v.findViewById(R.id.bch3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(getActivity(),c_hot.class);
                startActivity(j);
            }
        });
        return v;
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(getActivity(),c_places.class);
        startActivity(i);
    }
}
