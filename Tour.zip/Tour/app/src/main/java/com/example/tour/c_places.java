package com.example.tour;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class c_places extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_places);
    }
}
