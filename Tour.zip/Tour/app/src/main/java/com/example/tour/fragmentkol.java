package com.example.tour;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class fragmentkol extends Fragment implements View.OnClickListener{
   View v;

    public fragmentkol() {
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       v = inflater.inflate(R.layout.kolkata,container,false);
        Button b = (Button) v.findViewById(R.id.bk1);
        b.setOnClickListener(this);
        Button b2 =(Button) v.findViewById(R.id.bk2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(getActivity(),k_restro.class);
                startActivity(j);
            }
        });
        Button b3 = (Button) v.findViewById(R.id.bk3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  k  = new Intent(getActivity(),k_hot.class);
                startActivity(k);
            }
        });
        return v;
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(getActivity(),k_places.class);
        startActivity(i);
    }
}
